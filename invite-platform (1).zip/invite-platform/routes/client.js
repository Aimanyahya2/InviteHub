const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const db = require('../db');
const { resolveTenant } = require('../middleware/tenant');
const { requireClientAuth } = require('../middleware/auth');

const router = express.Router();

function getGuestCount(eventId) {
  return db.prepare('SELECT COUNT(*) AS c FROM guests WHERE event_id = ?').get(eventId).c;
}

// ---------- تسجيل دخول صاحب المناسبة ----------
router.get('/login', resolveTenant, (req, res) => {
  if (req.session.client && req.session.client.tenant_id === req.tenant.id) return res.redirect('/client');
  res.render('client_login', { title: 'دخول صاحب المناسبة', error: null });
});

router.post('/login', resolveTenant, (req, res) => {
  const { username, password } = req.body;
  const client = db.prepare(`
    SELECT ec.* FROM event_clients ec
    JOIN events e ON ec.event_id = e.id
    WHERE e.tenant_id = ? AND ec.username = ?
  `).get(req.tenant.id, username);

  if (!client || !bcrypt.compareSync(password || '', client.password_hash)) {
    return res.render('client_login', { title: 'دخول صاحب المناسبة', error: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
  }

  req.session.client = { id: client.id, username: client.username, event_id: client.event_id, tenant_id: req.tenant.id };
  res.redirect('/client');
});

router.post('/logout', (req, res) => {
  req.session.client = null;
  res.redirect('/client/login');
});

router.use(resolveTenant);
router.use(requireClientAuth);

// ---------- لوحة صاحب المناسبة ----------
router.get('/', (req, res) => {
  const event = db.prepare('SELECT * FROM events WHERE id = ?').get(req.session.client.event_id);
  const guests = db.prepare('SELECT * FROM guests WHERE event_id = ? ORDER BY created_at DESC').all(event.id);
  const count = guests.length;
  const pendingRequest = db.prepare(`
    SELECT * FROM guest_limit_requests WHERE event_id = ? AND status = 'قيد المراجعة' ORDER BY created_at DESC LIMIT 1
  `).get(event.id);
  const confirmed = guests.filter(g => g.rsvp === 'حضور').length;
  const checkedIn = guests.filter(g => g.checked_in_at).length;

  res.render('client_dashboard', {
    title: event.title,
    event, guests, count, confirmed, checkedIn, pendingRequest,
    flash: req.query.flash || null
  });
});

// ---------- إضافة مدعو (بحد أقصى حسب الاتفاق) ----------
router.post('/guests', (req, res) => {
  const event = db.prepare('SELECT * FROM events WHERE id = ?').get(req.session.client.event_id);
  const { name, phone } = req.body;
  if (!name || !name.trim()) {
    return res.redirect('/client?flash=اسم المدعو مطلوب');
  }

  const count = getGuestCount(event.id);
  if (event.max_guests && count >= event.max_guests) {
    return res.redirect(`/client?flash=وصلت الحد المسموح (${event.max_guests} مدعو) - ارفع طلب زيادة تحت`);
  }

  const token = uuidv4().split('-')[0];
  db.prepare('INSERT INTO guests (event_id, name, phone, token) VALUES (?, ?, ?, ?)')
    .run(event.id, name.trim(), (phone || '').trim(), token);
  res.redirect('/client');
});

router.post('/guests/:id/delete', (req, res) => {
  const guest = db.prepare(`
    SELECT g.* FROM guests g WHERE g.id = ? AND g.event_id = ?
  `).get(req.params.id, req.session.client.event_id);
  if (!guest) return res.status(404).send('غير موجود');
  db.prepare('DELETE FROM guests WHERE id = ?').run(req.params.id);
  res.redirect('/client');
});

// ---------- طلب زيادة العدد المسموح ----------
router.post('/request-increase', (req, res) => {
  const event = db.prepare('SELECT * FROM events WHERE id = ?').get(req.session.client.event_id);
  const { requested_total, note } = req.body;
  const total = parseInt(requested_total, 10);
  if (!total || total <= (event.max_guests || 0)) {
    return res.redirect('/client?flash=العدد المطلوب لازم يكون أكبر من الحد الحالي');
  }

  const existing = db.prepare(`SELECT id FROM guest_limit_requests WHERE event_id = ? AND status = 'قيد المراجعة'`).get(event.id);
  if (existing) {
    return res.redirect('/client?flash=فيه طلب سابق لسا قيد المراجعة');
  }

  db.prepare('INSERT INTO guest_limit_requests (event_id, requested_total, note) VALUES (?, ?, ?)')
    .run(event.id, total, note || null);
  res.redirect('/client?flash=تم إرسال طلبك، بانتظار موافقة منظّم المناسبة');
});

// ---------- صفحة الماسح الضوئي لصاحب المناسبة ----------
router.get('/scan', (req, res) => {
  const event = db.prepare('SELECT * FROM events WHERE id = ?').get(req.session.client.event_id);
  const guests = db.prepare('SELECT * FROM guests WHERE event_id = ?').all(event.id);
  const stats = {
    confirmed: guests.filter(g => g.rsvp === 'حضور').length,
    checked_in: guests.filter(g => g.checked_in_at).length
  };
  res.render('client_scan', { title: 'تسجيل الحضور', event, stats });
});

router.post('/checkin/:token', (req, res) => {
  const guest = db.prepare(`
    SELECT g.* FROM guests g WHERE g.token = ? AND g.event_id = ?
  `).get(req.params.token, req.session.client.event_id);

  if (!guest) return res.status(404).json({ ok: false, message: 'باركود غير معروف' });
  if (guest.checked_in_at) {
    return res.json({ ok: false, already: true, name: guest.name, message: `${guest.name} مسجّل حضوره مسبقًا` });
  }

  db.prepare("UPDATE guests SET checked_in_at = datetime('now') WHERE id = ?").run(guest.id);
  const guests = db.prepare('SELECT * FROM guests WHERE event_id = ?').all(guest.event_id);
  res.json({
    ok: true,
    name: guest.name,
    checked_in: guests.filter(g => g.checked_in_at).length,
    total: guests.filter(g => g.rsvp === 'حضور').length
  });
});

module.exports = router;
